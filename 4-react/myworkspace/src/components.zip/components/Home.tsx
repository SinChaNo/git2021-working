const Home = () => {
  return <div>This is Home Component</div>;
}

export default Home;